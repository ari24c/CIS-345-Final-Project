#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/param.h"
#include "kernel/pstat.h"
#include "user/user.h"

int
main(void)
{
  int tickets[3] = {30, 20, 10};

  for(int i = 0; i < 3; i++){
    int pid = fork();
 
    if(pid == 0){
      settickets(tickets[i]);

      while(1){
      }
   
      exit(0);
    }
  }
 
  pause(200);
  
  struct pstat ps;

  if(getpinfo(&ps) < 0){
    printf("getpinfo failed\n");
    exit(1);
  }

  printf("PID\tTickets\tTicks\n");

  for(int i = 0; i < NPROC; i++){
    if(ps.inuse[i] && (ps.tickets[i] == 30 || ps.tickets[i] == 20 || ps.tickets[i] == 10)){
      printf("%d\t%d\t%d\n", ps.pid[i], ps.tickets[i], ps.ticks[i]);
    }
  }

  exit(0);
}
